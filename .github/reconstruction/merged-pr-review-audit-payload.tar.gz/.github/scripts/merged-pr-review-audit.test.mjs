import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

import {
    applyAuditPolicy,
    auditCommentMarker,
    auditMergedPullRequest,
    blockingFindings,
    classifyReview,
    findingsAtOrAbove,
    parseReviewCommentCount,
    parseReviewCoverage,
    parseReviewerLogins,
    renderMarkdown,
    sanitizeMarkdownText,
    validateAuditPolicy
} from './merged-pr-review-audit.mjs';

const HEAD = 'a'.repeat(40);
const OTHER_HEAD = 'b'.repeat(40);
const POLICY_SOURCE = '9'.repeat(40);
const REVIEWERS = parseReviewerLogins('copilot-pull-request-reviewer[bot]');

function pullRequest(overrides = {}) {
    return {
        number: 933,
        state: 'closed',
        title: 'Example',
        html_url: 'https://github.example/pull/933',
        head: { sha: HEAD },
        base: { ref: 'qa/922-complete-ai-session' },
        changed_files: 2,
        merged_at: '2026-09-01T11:00:00Z',
        ...overrides
    };
}

function review(body, overrides = {}) {
    return {
        user: { login: 'copilot-pull-request-reviewer[bot]' },
        state: 'COMMENTED',
        commit_id: HEAD,
        submitted_at: '2026-09-01T10:00:00Z',
        body,
        ...overrides
    };
}

const APPROVAL = `### 🟢 Approval recommended

- **Files reviewed:** 2/2 changed files
- **Comments generated:** 0`;

const CHANGES = `### 🟡 Changes recommended

- **Files reviewed:** 2/2 changed files
- **Comments generated:** 1`;

const CLOSER = `### 🔵 Needs a closer look

- **Files reviewed:** 2/2 changed files
- **Comments generated:** 1`;

function policy(overrides = {}) {
    return {
        schemaVersion: 1,
        prospectiveEnforcement: {
            startedAt: '2026-09-01T21:07:50Z',
            sourceSha: POLICY_SOURCE,
            trackingIssue: 964,
            ...overrides.prospectiveEnforcement
        },
        dispositions: overrides.dispositions ?? []
    };
}

function highResult(overrides = {}) {
    return auditMergedPullRequest({
        pullRequest: pullRequest({
            merged_at: '2026-09-01T22:00:00Z',
            ...overrides.pullRequest
        }),
        reviews: overrides.reviews ?? [review(CHANGES, {
            submitted_at: '2026-09-01T22:01:00Z'
        })],
        threads: overrides.threads ?? [],
        reviewerLogins: REVIEWERS
    });
}

test('parses and classifies the review evidence contract', () => {
    assert.deepEqual(parseReviewCoverage(APPROVAL), { reviewed: 2, total: 2 });
    assert.equal(parseReviewCommentCount(APPROVAL), 0);
    assert.equal(classifyReview(review(APPROVAL)), 'approval-recommended');
    assert.equal(classifyReview(review(CHANGES)), 'changes-recommended');
    assert.equal(classifyReview(review(CLOSER)), 'needs-closer-look');
});

test('accepts a clean complete exact-head review before merge', () => {
    const result = auditMergedPullRequest({
        pullRequest: pullRequest(),
        reviews: [review(APPROVAL)],
        threads: [],
        reviewerLogins: REVIEWERS
    });
    assert.deepEqual(result.findings, []);
    assert.equal(result.baseRef, 'qa/922-complete-ai-session');
});

test('reports no exact-head pre-merge review as medium', () => {
    const result = auditMergedPullRequest({
        pullRequest: pullRequest(),
        reviews: [review(APPROVAL, { commit_id: OTHER_HEAD })],
        threads: [],
        reviewerLogins: REVIEWERS
    });
    assert.ok(result.findings.some(item =>
        item.code === 'NO_EXACT_HEAD_REVIEW_BEFORE_MERGE'
            && item.severity === 'medium'));
    assert.equal(findingsAtOrAbove(result.findings, 'high').length, 0);
});

test('reports an exact-head changes-recommended review submitted after merge as high', () => {
    const result = auditMergedPullRequest({
        pullRequest: pullRequest({ merged_at: '2026-09-01T09:00:00Z' }),
        reviews: [review(CHANGES)],
        threads: [],
        reviewerLogins: REVIEWERS
    });
    assert.ok(result.findings.some(item =>
        item.code === 'ACTIONABLE_REVIEW_SUBMITTED_AFTER_MERGE'
            && item.severity === 'high'));
});

test('reports a stale-head review after merge as medium rather than merged-head evidence', () => {
    const result = auditMergedPullRequest({
        pullRequest: pullRequest({ merged_at: '2026-09-01T09:00:00Z' }),
        reviews: [review(CHANGES, { commit_id: OTHER_HEAD })],
        threads: [],
        reviewerLogins: REVIEWERS
    });
    assert.ok(result.findings.some(item =>
        item.code === 'STALE_HEAD_REVIEW_SUBMITTED_AFTER_MERGE'
            && item.severity === 'medium'));
    assert.ok(!result.findings.some(item =>
        item.code === 'ACTIONABLE_REVIEW_SUBMITTED_AFTER_MERGE'));
});

test('reports an approval submitted after merge as medium when complete', () => {
    const result = auditMergedPullRequest({
        pullRequest: pullRequest({ merged_at: '2026-09-01T09:00:00Z' }),
        reviews: [review(APPROVAL)],
        threads: [],
        reviewerLogins: REVIEWERS
    });
    assert.ok(result.findings.some(item =>
        item.code === 'APPROVING_REVIEW_SUBMITTED_AFTER_MERGE'
            && item.severity === 'medium'));
});

test('reports partial coverage and comments without a clean exact-head re-review', () => {
    const result = auditMergedPullRequest({
        pullRequest: pullRequest(),
        reviews: [review(APPROVAL
            .replace('2/2', '1/2')
            .replace('Comments generated:** 0', 'Comments generated:** 2'))],
        threads: [],
        reviewerLogins: REVIEWERS
    });
    assert.ok(result.findings.some(item =>
        item.code === 'INCOMPLETE_EXACT_HEAD_REVIEW'));
    assert.ok(result.findings.some(item =>
        item.code === 'PRE_MERGE_REVIEW_FINDINGS_NOT_RECHECKED'));
});

test('reports unresolved current threads after merge and ignores outdated ones', () => {
    const result = auditMergedPullRequest({
        pullRequest: pullRequest(),
        reviews: [review(APPROVAL)],
        threads: [
            { isResolved: false, isOutdated: false, path: 'A.java' },
            { isResolved: false, isOutdated: true, path: 'Old.java' }
        ],
        reviewerLogins: REVIEWERS
    });
    const finding = result.findings.find(item =>
        item.code === 'UNRESOLVED_CURRENT_THREAD_AFTER_MERGE');
    assert.deepEqual(finding.paths, ['A.java']);
});

test('validates the prospective policy and rejects duplicate disposition keys', () => {
    const disposition = {
        pullRequestNumber: 933,
        headSha: HEAD,
        findingCode: 'ACTIONABLE_REVIEW_SUBMITTED_AFTER_MERGE',
        status: 'OPEN_TRACKED',
        trackingIssueNumber: 964,
        reason: 'Tracked in the frozen-SHA QA programme.'
    };
    assert.equal(validateAuditPolicy(policy({
        dispositions: [disposition]
    })).dispositions[0].status, 'OPEN_TRACKED');
    assert.throws(() => validateAuditPolicy(policy({
        dispositions: [disposition, disposition]
    })), /Duplicate disposition key/u);
});

test('rejects malformed policy fields and unverifiable fixed dispositions', () => {
    assert.throws(() => validateAuditPolicy({}), /schemaVersion/u);
    assert.throws(() => validateAuditPolicy(policy({
        prospectiveEnforcement: { sourceSha: 'not-a-sha' }
    })), /40-character/u);
    assert.throws(() => validateAuditPolicy(policy({
        dispositions: [{
            pullRequestNumber: 933,
            headSha: HEAD,
            findingCode: 'ACTIONABLE_REVIEW_SUBMITTED_AFTER_MERGE',
            status: 'FIXED',
            trackingIssueNumber: 970,
            reason: 'Fixed by the replacement PR.'
        }]
    })), /verifiedByCommit/u);
});

test('raises missing exact-head review evidence to blocking after the policy boundary', () => {
    const raw = auditMergedPullRequest({
        pullRequest: pullRequest({ merged_at: '2026-09-01T22:00:00Z' }),
        reviews: [],
        threads: [],
        reviewerLogins: REVIEWERS
    });
    const applied = applyAuditPolicy(raw, policy());
    const finding = applied.findings.find(item =>
        item.code === 'NO_EXACT_HEAD_REVIEW_BEFORE_MERGE');
    assert.equal(finding.severity, 'high');
    assert.equal(finding.policySeverityRaised, true);
    assert.equal(finding.blocking, true);
});

test('raises a complete but late approval to blocking after the policy boundary', () => {
    const raw = auditMergedPullRequest({
        pullRequest: pullRequest({ merged_at: '2026-09-01T22:00:00Z' }),
        reviews: [review(APPROVAL, {
            submitted_at: '2026-09-01T22:01:00Z'
        })],
        threads: [],
        reviewerLogins: REVIEWERS
    });
    const applied = applyAuditPolicy(raw, policy());
    const finding = applied.findings.find(item =>
        item.code === 'APPROVING_REVIEW_SUBMITTED_AFTER_MERGE');
    assert.equal(finding.severity, 'high');
    assert.equal(finding.policySeverityRaised, true);
    assert.equal(finding.blocking, true);
});

test('keeps historical high findings visible but non-blocking', () => {
    const raw = highResult({
        pullRequest: { merged_at: '2026-09-01T20:00:00Z' },
        reviews: [review(CHANGES, { submitted_at: '2026-09-01T20:01:00Z' })]
    });
    const applied = applyAuditPolicy(raw, policy());
    assert.equal(applied.historical, true);
    assert.ok(applied.findings.some(item => item.severity === 'high'));
    assert.equal(blockingFindings(applied).length, 0);
});

test('blocks prospective high findings without a terminal disposition', () => {
    const applied = applyAuditPolicy(highResult(), policy());
    assert.equal(applied.historical, false);
    assert.ok(blockingFindings(applied).some(item =>
        item.code === 'ACTIONABLE_REVIEW_SUBMITTED_AFTER_MERGE'));
});

test('OPEN_TRACKED remains blocking while FIXED with exact commit is terminal', () => {
    const raw = highResult();
    const code = 'ACTIONABLE_REVIEW_SUBMITTED_AFTER_MERGE';
    const open = applyAuditPolicy(raw, policy({ dispositions: [{
        pullRequestNumber: 933,
        headSha: HEAD,
        findingCode: code,
        status: 'OPEN_TRACKED',
        trackingIssueNumber: 971,
        reason: 'Repair is pending.'
    }] }));
    assert.ok(blockingFindings(open).some(item => item.code === code));

    const fixed = applyAuditPolicy(raw, policy({ dispositions: [{
        pullRequestNumber: 933,
        headSha: HEAD,
        findingCode: code,
        status: 'FIXED',
        trackingIssueNumber: 970,
        reason: 'Exact boundary repair was merged and verified.',
        verifiedByCommit: 'c'.repeat(40)
    }] }));
    assert.ok(!blockingFindings(fixed).some(item => item.code === code));
});

test('comment markers include the exact PR, head, and finding set', () => {
    const applied = applyAuditPolicy(highResult(), policy());
    const marker = auditCommentMarker(applied);
    assert.match(marker, /933:a{40}/u);
    assert.match(marker, /ACTIONABLE_REVIEW_SUBMITTED_AFTER_MERGE/u);
});

test('markdown output neutralizes untrusted title and base formatting', () => {
    const raw = highResult({
        pullRequest: {
            title: 'Unsafe\n## injected <tag> `code`',
            base: { ref: 'feature|table' }
        }
    });
    const applied = applyAuditPolicy(raw, policy());
    const markdown = renderMarkdown(
        [applied], 'one\nscope', validateAuditPolicy(policy()), POLICY_SOURCE);
    assert.doesNotMatch(markdown, /\n## injected/u);
    assert.match(markdown, /&lt;tag&gt;/u);
    assert.match(markdown, /feature\\\|table/u);
    assert.equal(sanitizeMarkdownText('a\nb'), 'a b');
});

test('workflow checks out trusted default-branch code and records exact source', async () => {
    const workflow = await readFile(
        new URL('../workflows/merged-pr-review-audit.yml', import.meta.url), 'utf8');
    assert.match(workflow, /pull_request_review:/u);
    assert.match(workflow, /schedule:/u);
    assert.match(workflow,
        /ref: \$\{\{ github\.event\.repository\.default_branch \}\}/u);
    assert.doesNotMatch(workflow, /ref: \$\{\{ github\.sha \}\}/u);
    assert.match(workflow, /git rev-parse HEAD/u);
    assert.match(workflow, /AUDIT_SOURCE_SHA:/u);
    assert.match(workflow, /AUDIT_POLICY_PATH:/u);
    assert.match(workflow, /pull-requests: read/u);
    assert.match(workflow, /issues: write/u);
    assert.match(workflow, /AUDIT_COMMENT: 'true'/u);
});
